//OPSI MENU
let rutinitas = document.getElementById("rutinitas")
let berzanji = document.getElementById("berzanji")
let about = document.getElementById("about")


about.addEventListener("click", function() {
    window.location.href = "about.html"
})

rutinitas.addEventListener("click", function() {
    window.location.href = "rutinitas.html"
})

berzanji.addEventListener("click", function() {
    window.location.href = "berzanji.html"
})
